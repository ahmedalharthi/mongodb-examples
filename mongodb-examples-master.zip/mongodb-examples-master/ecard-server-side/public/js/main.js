(() => {
  const viewContainer = document.querySelector('#creator-view');
  new CreatorView(viewContainer);
})();
